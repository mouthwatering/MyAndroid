package com.example.smartringdemo;

import android.app.Activity;

public class FeedBackActivity extends Activity{

}
