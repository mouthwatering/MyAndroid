package com.example.smartringdemo;

import android.app.Activity;

public class SOSsetting extends Activity{

}
